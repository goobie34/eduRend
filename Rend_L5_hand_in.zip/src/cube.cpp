#include "cube.h"

Cube::Cube(
	ID3D11Device* dxdevice,
	ID3D11DeviceContext* dxdevice_context, bool is_skybox)
	: Model(dxdevice, dxdevice_context)
{
	//Materials
	m_materials.push_back(DefaultMaterial);
	m_materials[0].Name = "Cube Material";
	m_materials[0].AmbientColour = { 1, 1, 1 };
	m_materials[0].DiffuseColour = { 1, 1, 1 };
	m_materials[0].SpecularColour = { 1, 1, 1 };
	m_materials[0].DiffuseTextureFilename = "assets/textures/crate.png";
	//m_materials[0].NormalTextureFilename = "assets/textures/Fieldstone_bump.png";

	//Textures
	if (m_materials[0].DiffuseTextureFilename.size()) {
		HRESULT hr = LoadTextureFromFile(
			dxdevice,
			dxdevice_context,
			m_materials[0].DiffuseTextureFilename.c_str(),
			&m_materials[0].DiffuseTexture);
		std::cout << "\t" << m_materials[0].DiffuseTextureFilename
			<< (SUCCEEDED(hr) ? " - OK" : "- FAILED") << std::endl;
	}

	if (m_materials[0].NormalTextureFilename.size()) {
		HRESULT hr = LoadTextureFromFile(
			dxdevice,
			dxdevice_context,
			m_materials[0].NormalTextureFilename.c_str(),
			&m_materials[0].NormalTexture);
		std::cout << "\t" << m_materials[0].NormalTextureFilename
			<< (SUCCEEDED(hr) ? " - OK" : "- FAILED") << std::endl;
	} else {
		HRESULT hr = LoadDefaultTexture(dxdevice, &m_materials[0].NormalTexture);
		std::cout << "\t" << "Default normal map texture"
			<< (SUCCEEDED(hr) ? " - OK" : "- FAILED") << std::endl;
	}

	//Geometry
	std::vector<Vertex> vertices;
	std::vector<unsigned> indices;

	//Create temporary vertex array
	Vertex v[24];

	//Front face
	v[0].Position = {-0.5, -0.5f, 0.5f};
	v[1].Position = { 0.5, -0.5f, 0.5f };
	v[2].Position = { 0.5, 0.5f, 0.5f };
	v[3].Position = { -0.5, 0.5f, 0.5f };

	//Right face
	v[4].Position = { 0.5, -0.5f, 0.5f };
	v[5].Position = { 0.5, -0.5f, -0.5f };
	v[6].Position = { 0.5, 0.5f, -0.5f };
	v[7].Position = { 0.5, 0.5f, 0.5f };

	//Back face
	v[8].Position = { 0.5, -0.5f, -0.5f };
	v[9].Position = { -0.5, -0.5f, -0.5f };
	v[10].Position = { -0.5, 0.5f, -0.5f };
	v[11].Position = { 0.5, 0.5f, -0.5f };

	//Left Face
	v[12].Position = { -0.5, -0.5f, -0.5f };
	v[13].Position = { -0.5, -0.5f, 0.5f };
	v[14].Position = { -0.5, 0.5f, 0.5f };
	v[15].Position = { -0.5, 0.5f, -0.5f };
	
	//Top Face
	v[16].Position = { -0.5, 0.5f, 0.5f };
	v[17].Position = { 0.5, 0.5f, 0.5f };
	v[18].Position = { 0.5, 0.5f, -0.5f };
	v[19].Position = { -0.5, 0.5f, -0.5f };
	
	//Bottom Face
	v[20].Position = { -0.5, -0.5f, 0.5f };
	v[21].Position = { 0.5, -0.5f, 0.5f };
	v[22].Position = { 0.5, -0.5f, -0.5f };
	v[23].Position = { -0.5, -0.5f, -0.5f };

	//Array of texture coordinates for each corner of cube face
	vec2f corner_tex_coords[4] = {{0,0}, {0,1}, {1, 1}, {1, 0}};
	vec3f normals[6] = { {0,0, 1}, {1,0,0}, {0, 0, -1}, {-1,0 ,0}, {0, 1, 0}, {0, -1, 0} }; //order of normals for: front, right, back, left, top, bottom

	//Set normals and texture coordinates, then add to vertex buffer
	for (int i = 0; i < 24; i++) {
		v[i].Normal = normals[(int)(i / 4)] * (is_skybox ? -1 : 1); //first four vertices get normals[0], next four get normals[1] and so on, invert them if this is a skybox
		v[i].TexCoord = corner_tex_coords[i % 4]; //ensures that corners of cube a face matches corner of texture space
		vertices.push_back(v[i]);
	}

	//cube map mode is used in PS to calculate reflection
	//default is 0 = no cube mapping, 3 = skybox
	//SetCubeMapMode(3);
	// Populate the index array with triangles, order vertices depend on if this cube is a skybox
	if (!is_skybox) {
		// Triangle #1
		indices.push_back(0);
		indices.push_back(1);
		indices.push_back(3);
		//Triangle #2
		indices.push_back(1);
		indices.push_back(2);
		indices.push_back(3);
		// Triangle #3
		indices.push_back(4);
		indices.push_back(5);
		indices.push_back(7);
		// Triangle #4
		indices.push_back(5);
		indices.push_back(6);
		indices.push_back(7);
		// Triangle #5
		indices.push_back(8);
		indices.push_back(9);
		indices.push_back(11);
		// Triangle #6
		indices.push_back(9);
		indices.push_back(10);
		indices.push_back(11);
		// Triangle #7
		indices.push_back(12);
		indices.push_back(13);
		indices.push_back(15);
		// Triangle #8
		indices.push_back(13);
		indices.push_back(14);
		indices.push_back(15);
		// Triangle #9
		indices.push_back(16);
		indices.push_back(17);
		indices.push_back(19);
		// Triangle #10
		indices.push_back(17);
		indices.push_back(18);
		indices.push_back(19);
		// Triangle #11
		indices.push_back(23);
		indices.push_back(22);
		indices.push_back(20);
		// Triangle #12
		indices.push_back(22);
		indices.push_back(21);
		indices.push_back(20);
	}
	else {
		// Populate the index array with triangles (REVERSED for inside-out viewing)
		// Triangle #1 (was 0, 1, 3)
		indices.push_back(0);
		indices.push_back(3);
		indices.push_back(1);

		// Triangle #2 (was 1, 2, 3)
		indices.push_back(1);
		indices.push_back(3);
		indices.push_back(2);

		// Triangle #3 (was 4, 5, 7)
		indices.push_back(4);
		indices.push_back(7);
		indices.push_back(5);

		// Triangle #4 (was 5, 6, 7)
		indices.push_back(5);
		indices.push_back(7);
		indices.push_back(6);

		// Triangle #5 (was 8, 9, 11)
		indices.push_back(8);
		indices.push_back(11);
		indices.push_back(9);

		// Triangle #6 (was 9, 10, 11)
		indices.push_back(9);
		indices.push_back(11);
		indices.push_back(10);

		// Triangle #7 (was 12, 13, 15)
		indices.push_back(12);
		indices.push_back(15);
		indices.push_back(13);

		// Triangle #8 (was 13, 14, 15)
		indices.push_back(13);
		indices.push_back(15);
		indices.push_back(14);

		// Triangle #9 (was 16, 17, 19)
		indices.push_back(16);
		indices.push_back(19);
		indices.push_back(17);

		// Triangle #10 (was 17, 18, 19)
		indices.push_back(17);
		indices.push_back(19);
		indices.push_back(18);

		// Triangle #11 (was 23, 22, 20)
		indices.push_back(23);
		indices.push_back(20);
		indices.push_back(22);

		// Triangle #12 (was 22, 21, 20)
		indices.push_back(22);
		indices.push_back(20);
		indices.push_back(21);
	}
	
	// Vertex array descriptor
	D3D11_BUFFER_DESC vertexbufferDesc{ 0 };
	vertexbufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	vertexbufferDesc.CPUAccessFlags = 0;
	vertexbufferDesc.Usage = D3D11_USAGE_DEFAULT;
	vertexbufferDesc.MiscFlags = 0;
	vertexbufferDesc.ByteWidth = (UINT)(vertices.size() * sizeof(Vertex));
	// Data resource
	D3D11_SUBRESOURCE_DATA vertexData = { 0 };
	vertexData.pSysMem = &vertices[0];
	// Create vertex buffer on device using descriptor & data
	dxdevice->CreateBuffer(&vertexbufferDesc, &vertexData, &m_vertex_buffer);
	SETNAME(m_vertex_buffer, "VertexBuffer");

	//  Index array descriptor
	D3D11_BUFFER_DESC indexbufferDesc = { 0 };
	indexbufferDesc.BindFlags = D3D11_BIND_INDEX_BUFFER;
	indexbufferDesc.CPUAccessFlags = 0;
	indexbufferDesc.Usage = D3D11_USAGE_DEFAULT;
	indexbufferDesc.MiscFlags = 0;
	indexbufferDesc.ByteWidth = (UINT)(indices.size() * sizeof(unsigned));
	// Data resource
	D3D11_SUBRESOURCE_DATA indexData{ 0 };
	indexData.pSysMem = &indices[0];
	// Create index buffer on device using descriptor & data
	dxdevice->CreateBuffer(&indexbufferDesc, &indexData, &m_index_buffer);
	SETNAME(m_index_buffer, "IndexBuffer");

	m_number_of_indices = (unsigned int)indices.size();
}

void Cube::Render() const
{
	// Bind our vertex buffer
	const UINT32 stride = sizeof(Vertex); //  sizeof(float) * 8;
	const UINT32 offset = 0;
	m_dxdevice_context->IASetVertexBuffers(0, 1, &m_vertex_buffer, &stride, &offset);

	// Bind our index buffer
	m_dxdevice_context->IASetIndexBuffer(m_index_buffer, DXGI_FORMAT_R32_UINT, 0);
	
	m_dxdevice_context->PSSetShaderResources(0, 1, &m_materials[0].DiffuseTexture.TextureView);
	m_dxdevice_context->PSSetShaderResources(1, 1, &m_materials[0].NormalTexture.TextureView);

	//Update and bind material buffer
	UpdateMaterialBuffer(vec4f(m_materials[0].AmbientColour, 1), vec4f(m_materials[0].DiffuseColour, 1), vec4f(m_materials[0].SpecularColour, 1), m_cube_map_mode);
	m_dxdevice_context->PSSetConstantBuffers(1, 1, &m_material_buffer);

	// Make the drawcall
	m_dxdevice_context->DrawIndexed(m_number_of_indices, 0, 0);
}

Cube::~Cube(){
	for (auto& material : m_materials)
	{
		SAFE_RELEASE(material.DiffuseTexture.TextureView);

		// Release other used textures ...
	}
}